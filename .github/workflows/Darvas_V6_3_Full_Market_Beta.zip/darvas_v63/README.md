# Darvas V6.3 — full U.S. market research beta

**Standalone addition**: copy `v6_3/` and `.github/workflows/darvas-v63.yml` into the *root* of your existing repository. Existing V6/V6.2 files are not replaced.

## GitHub Actions
1. Commit the two paths to `main`.
2. Actions → **Darvas V6.3 Full Market Daily** → Run workflow → `limit=100` for a smoke test.
3. Inspect the uploaded `darvas-v63-<run>` artifact. When reliable, rerun with `limit=0` for all eligible stocks.
4. Scheduled runs scan all eligible stocks. Free Yahoo Finance endpoints may throttle, fail or exceed GitHub Actions time limits. For reliable full-market scanning, use a licensed batch OHLCV provider, caching and resumable checkpoints.

## Local
```bash
python -m pip install -r v6_3/requirements_v63.txt
python v6_3/darvas_v63.py universe --limit 100
python v6_3/darvas_v63.py scan --limit 100
python v6_3/darvas_v63.py backtest --symbol ACN --period 5y
```

## Outputs
`v6_3/output/`: `universe.csv`, `scan_all.csv`, `signals.csv`, `download_failures.csv`, `darvas_v63_report.xlsx`, and optional backtest files.

## Methodology and limitations
- Official Nasdaq Trader directory files supply symbol listings. This is *listed stocks*, not every OTC stock or every security. The company/security-type name filter is heuristic and may misclassify ADRs, SPACs, or special instruments.
- The classic box engine is a **causal mechanical interpretation**: confirm a candidate high after three sessions without a higher high, then confirm a candidate low after three sessions without a lower low. Darvas book concepts are not a complete machine-readable specification.
- Daily breakout signals use prior-known box top, current high and close; these are **end-of-day signals**, not intraday executable alerts.
- `RECOVERY_WATCH` is a modern extension, **not** a Classic Darvas buy recommendation. It detects >=30% recovery above a prior rolling low while >=15% below the prior 52-week high; threshold can be changed.
- `WATCH`, `HIGHER_BOX`, `NEAR_BREAKOUT`, `BREAKOUT` are discovery labels, not trade instructions. Box logic is intentionally conservative and requires further validation with test cases.
- Backtest is a **single-symbol, single-position baseline** using next-open fills, protective stops and transaction costs. It does **not** implement Darvas pyramiding, a full trade lifecycle, intraday stops, portfolio allocation or market leadership filters. It is not a complete book-faithful engine yet.
- Universe list refresh is daily and no fixed cap is applied with `--limit 0`. Price/liquidity filters are applied during scan, not during universe generation.
- yfinance is an unofficial research data source and is not suitable for production trading; check data vendor terms and usage restrictions.
- This code does not connect to brokers, place orders or guarantee profitability.
